#include "client_net.h"
#include "mail.h"
#include "identify.h"
#define SERVERIP "192.168.43.38"
#define SERVERPORT 5000

client_base t;
Mail_recv mr;
Mail_send ms;
Mail_recv_list ml;
Identify ide;

int main(){
	///
	sockaddr_in addr;
	int sock = t.run_sock(SERVERIP, SERVERPORT, addr);
	std::vector<Mail_head> vec;
	ml.set_sock(sock);
	ml.set_name("burenhu");
	ml.get_mail(vec, 3);
	for(int i=0;i<vec.size();i++){
		printf("%s,%s,%s\n",vec[i].ID,vec[i].title,vec[i].state);
	}
	t.send_str(sock, "close");
   printf("close\n");
   
	close(sock);
	return 0;
}
