/*
* 文件名：attach.h
* 创建人：吴季孔
* 创建时间：2020-9-14
* 描述：附件类
*/
#pragma once
#include "client_net.h"

class Attachment: private client_base{
	public:

	private:
		std::string path;

};