#include "client_net.h"
#include "mail.h"
#include "identify.h"
#define SERVERIP "192.168.43.38"
#define SERVERPORT 5000


Mail_recv mr;
Mail_send ms;
Mail_recv_list ml;
Identify ide;

int main(){
	///
	sockaddr_in addr;
	int sock = client_base::run_sock(SERVERIP, SERVERPORT, addr);
	std::vector<Mail_head> vec;
	ml.set_sock(sock);
	ml.set_name("burenhu");
	ml.get_mail(vec, 3);
	for(int i=0;i<vec.size();i++){
		printf("%s,%s,%s\n",vec[i].ID,vec[i].title,vec[i].state);
	}
   printf("close\n");
   client_base::close_sock(sock);
	return 0;
}

int str2int(char *str){
	int len = 2;
}
