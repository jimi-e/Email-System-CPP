/*
* 文件名：client_net.h
* 创建人：吴季孔
* 创建时间：2020-9-11
* 描述：客户端网络通信底层实现
*/

#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

class net_client{
	public:
		static const char serverIP[20];
		static const int port;
		virtual int Send() = 0;
		virtual int Recv() = 0;
};
const char net_client::serverIP[20] = "127.0.0.1";
const int net_client::port = 5000;

class client_base{
	const int send_buf_size = 1024;
	const int recv_buf_size = 1024;
	public:

	inline void exit_char(const char*msg);

	int run_sock(const char *IP, int port, sockaddr_in &addr, sa_family_t AF = AF_INET);

	int send_str(int sock, const char *msg);

	int receive_str(int sock, std::string &msg);
	
	int send_file(int client_socket, const char *path);
};

void client_base::exit_char(const char*msg){
	printf(msg);
	exit(1);
}

int client_base::run_sock(const char *IP, int port, sockaddr_in &addr, sa_family_t AF){
	int sock = socket(AF, SOCK_STREAM, 0);
	if(sock<0) exit_char("socket err\n");
	///
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr(IP);
	addr.sin_port = htons(port);
	///
	if(connect(sock, (sockaddr *)&addr, sizeof(addr))<0) exit_char("connect err\n");
	return sock;
}

int client_base::send_str(int sock, const char *msg){
	//计算发送大小 发送块数量 余量大小
	int send_size = strlen(msg)+1, block_num = send_size/(send_buf_size), r_send_size = send_size%send_buf_size;
	char send_buf[send_buf_size];//发送缓冲区
	char recv_buf[recv_buf_size];//接收缓冲区
	//循环发送块
	for(int i=0;i<block_num;i++){
		memcpy(send_buf, msg+i*send_buf_size, sizeof(char)*send_buf_size);
		send(sock, send_buf, send_buf_size, 0);
		//对方确认接收后返回 "*#*#received#*#*"
		recv(sock, recv_buf, recv_buf_size, 0);
		if(strcmp(recv_buf, "*#*#received#*#*")!=0) exit_char("recv err\n");
	}
	//发送不足一块的余量
	if(r_send_size>0){
		memcpy(send_buf, msg+block_num*send_buf_size, sizeof(char)*r_send_size);
		send(sock, send_buf, r_send_size, 0);
		recv(sock, recv_buf, recv_buf_size, 0);
		if(strcmp(recv_buf, "*#*#received#*#*")!=0) exit_char("recv err\n");
	}
	//发送结束标志
	send(sock, "*#*#sendend#*#*", 16, 0);
	printf("*#*#sendend#*#*\n");
	recv(sock, recv_buf, recv_buf_size, 0);
	printf("received \"%s\".\n", recv_buf);
	return send_size;//返回发送字节数
}

int client_base::receive_str(int sock, std::string &msg){
	msg.clear();
	char recv_buf[recv_buf_size+1];
    while (1){
		recv(sock, recv_buf, recv_buf_size, 0);
		recv_buf[recv_buf_size] = 0;
		if(strcmp(recv_buf, "*#*#sendend#*#*")==0){
			break;
		}
		send(sock, "*#*#received#*#*", 17, 0);
		msg+=recv_buf;
	}
	send(sock, "received", 9, 0);
	return msg.length();
}

int client_base::send_file(int client_socket, const char *path){
     char send_buf[send_buf_size+5];
     char ch;
        scanf("%s",send_buf);
        if(freopen(send_buf, "r",stdin)!=NULL){

            send(client_socket,"##@##",send_buf_size,0);//告诉服务器要传文件
            send(client_socket,send_buf,send_buf_size,0);//传文件名
            int cnt=0;

            while((ch=getchar()) != EOF){

                send_buf[cnt++]=ch;//buf缓冲区大小为send_buf_size，也就是每读send_buf_size个字符，传送一次

                if(cnt == send_buf_size){
                    send_buf[cnt]=0,cnt=0;
                    send(client_socket,send_buf,send_buf_size,0);
                }

            }

            if(cnt != 0)
            {
                send_buf[cnt]=0,cnt=0;send(client_socket,send_buf,send_buf_size,0);
            }//传送最后不足send_buf_size的部分

            send(client_socket,"##@##",send_buf_size,0);//表示传送完毕
            fclose(stdin);
            freopen("/dev/tty","r",stdin);//attention!!!
        }
        else
        {
            printf("open wrong file....\n");
            exit(1);
        }
}